class Formas {
    protected String color;
    
    public void dibujar() {
        System.out.println("Dibujando una forma");
    }
    
    public void establecerColor(String color) {
        this.color = color;
    }
}