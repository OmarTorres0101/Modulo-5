public class Main {
    public static void main(String[] args) {
        Circulo c = new Circulo(5.0);
        c.dibujar();
        System.out.println("Radio: " + c.getRadio());
        
        Linea l = new Linea(10.0);
        l.dibujar();
        
        Triangulo t = new Triangulo(60);
        t.dibujar();
        System.out.println("Área del Triángulo: " + t.calcularArea(5, 10));
        
        Cuadrado q = new Cuadrado(4);
        q.dibujar();
        System.out.println("Área del Cuadrado: " + q.calcularArea());
    }
}
